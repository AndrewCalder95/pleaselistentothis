package com.codeclan.pleaselistentothis.pleaselistentothis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PleaselistentothisApplicationTests {

	@Test
	void contextLoads() {
	}

}
